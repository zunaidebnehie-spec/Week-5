# Week 05 Journal

## Student Information
- Name: Zunaid Ebne Hie
- Student ID: 12221209

---

# Task 2 – View Routing Table

## Routing Table Screenshot
A screenshot of the routing table should be added here after running the PowerShell command:

```powershell
Get-NetRoute
```

## Simple Routing Table Explanation
A routing table tells the computer where to send packets. Each row normally includes a destination network, subnet mask or prefix length, next-hop gateway, interface, and metric.

Example explanation:
- Destination `0.0.0.0/0` means the default route. It is used when no more specific route exists.
- The gateway is the next device that packets are sent to, usually the router.
- The interface is the local network adapter used to send the packet.
- The metric shows route priority. A lower metric is usually preferred.

---

# Task 3 – IP Network Design

## Group Member
- Zunaid Ebne Hie

## Addressing Plan
Student ID: 12221209  
Last four digits: 1209  
LAN 1 network selected using student ID: `12.9.1.0/24`

| Device | Interface | IP Address | Network |
|---|---|---|---|
| PC1 | Ethernet | 12.9.1.10 | 12.9.1.0/24 |
| PC2 | Ethernet | 12.9.1.11 | 12.9.1.0/24 |
| PC3 | Ethernet | 12.9.1.12 | 12.9.1.0/24 |
| Router 1 | LAN Interface | 12.9.1.1 | 12.9.1.0/24 |
| Router 1 | WAN Interface | 192.168.50.1 | 192.168.50.0/24 |
| Router 2 | WAN Interface | 192.168.50.2 | 192.168.50.0/24 |
| Router 2 | LAN Interface | 10.20.2.1 | 10.20.2.0/24 |
| PC4 | Ethernet | 10.20.2.10 | 10.20.2.0/24 |
| PC5 | Ethernet | 10.20.2.11 | 10.20.2.0/24 |

## Network Diagram
File included:
- week5-task3-network-diagram.png
- week5-task3-network-diagram.drawio

## Simplified Routing Tables

### PC1, PC2, and PC3
| Destination | Next Hop |
|---|---|
| 12.9.1.0/24 | Directly connected |
| 0.0.0.0/0 | 12.9.1.1 |

### Router 1
| Destination | Next Hop |
|---|---|
| 12.9.1.0/24 | Directly connected |
| 192.168.50.0/24 | Directly connected |
| 10.20.2.0/24 | 192.168.50.2 |

### Router 2
| Destination | Next Hop |
|---|---|
| 10.20.2.0/24 | Directly connected |
| 192.168.50.0/24 | Directly connected |
| 12.9.1.0/24 | 192.168.50.1 |

### PC4 and PC5
| Destination | Next Hop |
|---|---|
| 10.20.2.0/24 | Directly connected |
| 0.0.0.0/0 | 10.20.2.1 |

## ICMP/IP Packet Explanation
If PC1 sends a ping request to PC4, the IP packet will contain:
- Source IP: 12.9.1.10
- Destination IP: 10.20.2.10
- Protocol: ICMP Echo Request

The Ethernet frame MAC addresses depend on where the packet is captured. At a router, the source MAC will be the MAC address of the sender or previous router interface, and the destination MAC will be the next-hop router interface. The IP addresses remain the same from source to destination, but MAC addresses change at each hop.

---

# Task 4 – Academic Integrity Outcomes

## Scenario Summary
The most relevant scenario discussed was a student submitting work that was not fully their own, such as copying another student's assessment or using online material without proper acknowledgement.

## Outcome According to CQU Policy
This may be considered academic misconduct because the submitted work does not honestly represent the student's own learning. Possible outcomes can include a warning, mark reduction, resubmission requirement, or a fail grade depending on the seriousness of the breach.

## Recommendations
1. Always write assessment answers in your own words and reference any sources used.
2. Ask the tutor for help early instead of copying from another student or online source.

---

# Task 5 – IP Address Lookup

## Explanation
An online IP address lookup website normally identifies the public IP address of the network, not the exact computer. It may show the city or general area, but it usually does not show the exact house or classroom location.

## Example Result
- Home Internet: showed public IP and approximate city.
- Mobile Network: showed mobile provider network and approximate location.

## Accuracy
The lookup was partly accurate because it could identify the general location and internet provider, but it was not exact enough to identify the precise physical location.
